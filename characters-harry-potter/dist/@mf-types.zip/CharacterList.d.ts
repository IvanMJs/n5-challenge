export * from './compiled-types/components/CharacterList/CharacterList';
export { default } from './compiled-types/components/CharacterList/CharacterList';