import type React from "react";
interface Props {
    language: string;
}
declare const CharacterList: React.FC<Props>;
export default CharacterList;
